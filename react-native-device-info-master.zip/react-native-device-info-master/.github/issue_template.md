<!--
Hi there and thank you for reporting a bug! 🐛🐛🐛

If you want to submit a feature request, use this link instead:
  https://github.com/react-native-device-info/react-native-device-info/issues/new?template=feature_request.md
-->

## Summary

|             |     |
| ----------- | --- |
| Version     | ?   |
| Affected OS | ?   |
| OS Version  | ?   |

## Current behavior

<!-- Describe the issue you are facing, including any available error
message, logs, stack trace .. -->

## Expected behavior

<!-- What should have happened instead of this bug -->
