//
//  ActionExtension.h
//  example
//
//  Created by Dustin Schie on 10/13/20.
//

#import <Foundation/Foundation.h>
#import <React/RCTBridge.h>
NS_ASSUME_NONNULL_BEGIN

@interface ActionExtension : NSObject<RCTBridgeModule>

@end

NS_ASSUME_NONNULL_END
