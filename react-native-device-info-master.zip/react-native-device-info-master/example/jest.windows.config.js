module.exports = {
  testMatch: ['**/__windows_tests__/**/*.[jt]s?(x)'],
  setupFiles: ['./jest-windows/jest.setup.js']
}
  