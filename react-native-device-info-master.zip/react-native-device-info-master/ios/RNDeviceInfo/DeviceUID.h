#import <Foundation/Foundation.h>

@interface DeviceUID : NSObject
+ (NSString *)syncUid;
+ (NSString *)uid;
@end
